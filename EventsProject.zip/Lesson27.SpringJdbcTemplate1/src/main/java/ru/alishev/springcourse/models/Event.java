package ru.alishev.springcourse.models;


import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

public class Event {

    private int id;

    @NotEmpty(message = "Title should not be empty")
    @Size(min = 2, max = 100, message = "Time should be between 2 and 100 characters")
    private String title;

    @NotEmpty(message = "Place should not be empty")
    @Size(min = 2, max = 100, message = "Place should be between 2 and 100 characters")
    private String place;


    private LocalDateTime startdate;


    private LocalDateTime enddate;


    private LocalDateTime time_created;


    public Event(){

    }


    public Event(String title, String place, LocalDateTime startdate, LocalDateTime enddate, LocalDateTime time_created) {
        this.title = title;
        this.place = place;
        this.startdate = startdate;
        this.enddate = enddate;
        this.time_created = time_created;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public LocalDateTime getStartdate() {
        return startdate;
    }

    public void setStardate(LocalDateTime stardate) {
        this.startdate = stardate;
    }

    public LocalDateTime getEnddate() {
        return enddate;
    }

    public void setEnddate(LocalDateTime enddate) {
        this.enddate = enddate;
    }

    public LocalDateTime getTime_created() {
        return time_created;
    }

    public void setTime_created(LocalDateTime time_created) {
        this.time_created = time_created;
    }
}

