package ru.alishev.springcourse.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import ru.alishev.springcourse.models.Event;

import java.util.List;

@Component
public class EventDAO {


    private final JdbcTemplate jdbcTemplate;



    @Autowired
    public EventDAO(JdbcTemplate jdbcTemplate){
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Event> index(){
        return jdbcTemplate.query("SELECT * FROM events", new BeanPropertyRowMapper<>(Event.class));
    }


    public Event show(int id) {
        return jdbcTemplate.query("SELECT * FROM events WHERE id=?", new Object[]{id}, new BeanPropertyRowMapper<>(Event.class))
                .stream().findAny().orElse(null);
    }

    public void save(Event event) {
        jdbcTemplate.update("INSERT INTO events(title, place, startdate, enddate, time_created) VALUES(?, ?, ?, ?, ?)", event.getTitle(), event.getPlace(), event.getStartdate(), event.getEnddate(), event.getTime_created());
    }

    public void delete(int id) {
        jdbcTemplate.update("DELETE FROM events WHERE id=?", id);
    }







}
